package PrePracticaHerencia;

public class TestHumanidad {

	public static void main(String[] args) {
		
		Persona p1 = new Persona("Alvaro");
		
		
		p1.hablar();

	}

}
