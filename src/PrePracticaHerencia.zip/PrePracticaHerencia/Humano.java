package PrePracticaHerencia;

public abstract class Humano {

}
