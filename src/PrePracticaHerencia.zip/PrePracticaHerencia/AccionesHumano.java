package PrePracticaHerencia;

public interface AccionesHumano {

	public void bailar();
	public void tocarInstrumentos();
	public void estudiar();
	public void trabajar();
	
	
	
	
	
}
