package PrePracticaHerencia;

public class Hombre extends Persona{

	public Hombre(String nombre) {
		super(nombre);
		
	}
	

	

}
