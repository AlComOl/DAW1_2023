package PrePracticaHerencia;

public interface AccionesGeneral {

	
	public void hablar();
	public void desplazarse();
	public void jugar();
	public void alimentarse();
	public void dormir();
}
