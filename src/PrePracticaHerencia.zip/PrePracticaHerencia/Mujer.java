package PrePracticaHerencia;

public class Mujer extends Humano{
	
	

}
